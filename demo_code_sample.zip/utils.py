def helper():
    print('This is a utility function')